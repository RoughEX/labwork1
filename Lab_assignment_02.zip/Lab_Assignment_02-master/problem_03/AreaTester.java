package problem_03;

public class AreaTester {
    public int getArea(int height, int width){
        return height*width;
    }   
}
