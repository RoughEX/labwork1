package problem_04;

public class PerimeterTester {
    public int getPerimeter(int height, int width){
        return 2*(height+width);
    }   
}