package problem_02;

public class Using_trim_and_replace {

    public String useTrim(String something){
        return something.trim();
    }

    public String useReplaceAllSpaces(String something){
        return something.replace(" ","");
    }
    
}
