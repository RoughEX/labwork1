package problem_05;

import java.awt.*;

public class Construct_Rectangle {
    public static void main(String[] args) {
        Rectangle rec1 = new Rectangle(5, 5 ,6,7);
        Rectangle rec2 = new Rectangle (10, 10, 9, 12);
        System.out.println("Rec1's width is: " + rec1.getWidth()+ " and Rec1's height is: " +rec1.getHeight());
        System.out.println("Rec2's width is: " + rec2.getWidth()+ " and Rec2's height is: " +rec2.getHeight());
        }
    
}
